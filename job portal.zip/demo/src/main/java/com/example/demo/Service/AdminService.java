package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Admin;
import com.example.demo.Repository.AdminRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class AdminService {
    @Autowired
    AdminRepo adminRepo;

    public Admin addAdmin(Admin admin){
        return adminRepo.save(admin);
    }

    public List<Admin> viewAdmin(){
        return adminRepo.findAll();
    }

    public void deleteAdmin(Long id){
        if(adminRepo.existsById(id)){
            adminRepo.deleteById(id);
        }
        else{
            throw new EntityNotFoundException("Entity Not Found");
        }
    }

    public Admin updateAdmin(Long id,Admin adminDetails){
        Admin existingAdmin= adminRepo.findById(id).orElseThrow(()-> new EntityNotFoundException("Admin not found"));
        adminDetails.setId(id);
        existingAdmin.setId(adminDetails.getId());
        existingAdmin.setEmail(adminDetails.getEmail());
        existingAdmin.setName(adminDetails.getName());

        return adminRepo.save(existingAdmin);
    }

    public Page<Admin> getMethod(int size,int page){
        Pageable pageable=PageRequest.of(page, size);
        return adminRepo.findAll(pageable);
    }

    public List<Admin> sortbyName(){
        return adminRepo.findAll(Sort.by(Sort.Direction.DESC,"name"));
    }

    public List<Admin> getbyAdminname(String name){
        return adminRepo.findByAdminName(name);
    }

    public List<Admin> getbyemail(String email){
        return adminRepo.findByEmail(email);
    }
}
