package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.Company;

@Repository
public interface CompanyRepo extends JpaRepository<Company ,Long>{
    List<Company> findByName(String name);

    @Query("SELECT e FROM Company e WHERE e.location= :location")
    List<Company> findByLocation(String location);
}