package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Admin;
import com.example.demo.Service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    AdminService adminService;

    @GetMapping("/view")
    public List<Admin> viewAdmin(){
        return adminService.viewAdmin();
    }

    @PostMapping("/add")
    public Admin addAdmin(@RequestBody Admin admin){
        return adminService.addAdmin(admin);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteAdmin(@PathVariable long id){
        adminService.deleteAdmin(id);
        return ResponseEntity.ok("Admin Deleted Successfully");
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Admin> updateAdmin(@PathVariable Long id, @RequestBody Admin adminDetails){
        Admin updatedAdmin= adminService.updateAdmin(id, adminDetails);
        return ResponseEntity.ok(updatedAdmin);
    }

    @GetMapping("/pagination")
    public Page<Admin> getMethod(@RequestParam int page,@RequestParam int size){
        return adminService.getMethod(size, page);
    }

    @GetMapping("/sorted")
    public List<Admin> sortbyName(){
        return adminService.sortbyName();
    }

    @GetMapping("/jpql")
    public List<Admin> getbyAdminname(@RequestParam("name") String name){
        return adminService.getbyAdminname(name);
    }

    @GetMapping("/custom-jpa")
    public List<Admin> getbyemail(@RequestParam("email") String email){
        return adminService.getbyemail(email);
    }
}
