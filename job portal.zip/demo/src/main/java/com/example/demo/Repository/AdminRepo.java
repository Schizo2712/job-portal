package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.Admin;
import java.util.List;


@Repository
public interface AdminRepo extends JpaRepository<Admin, Long>{
    
    @Query("SELECT a from Admin a  WHERE a.name = :name")
    List<Admin> findByAdminName(@Param("name") String name);

    List<Admin> findByEmail(String email);
}
