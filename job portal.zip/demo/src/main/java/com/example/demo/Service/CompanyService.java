package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


import com.example.demo.Entity.Company;
import com.example.demo.Repository.CompanyRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class CompanyService {
    @Autowired
    CompanyRepo companyRepo;

    public Company addCompany(Company company){
        return companyRepo.save(company);
    }

    public List<Company> viewCompany(){
        return companyRepo.findAll();
    }

    public String deleteCompany(Long id){
        if(companyRepo.existsById(id)){
            companyRepo.deleteById(id);
            return "Record deleted successfully";
        }
        else{
            return "No record found.";
        }
    }

    public Company updateCompany(Long id,Company company){
        Company comp= companyRepo.findById(id).orElseThrow(()-> new EntityNotFoundException("Admin not found"));
        company.setId(id);
        comp.setId(company.getId());
        comp.setName(company.getName());
        comp.setLocation(company.getLocation());
        comp.setIndustry(company.getIndustry());
        comp.setDescription(company.getDescription());

        return companyRepo.save(company);
    }

    public Page<Company> getMethod(int size,int page){
        Pageable pageable=PageRequest.of(page, size);
        return companyRepo.findAll(pageable);
    }

    public List<Company> sortbyName(){
        return companyRepo.findAll(Sort.by(Sort.Direction.ASC,"name"));
    }

    public List<Company> getbyName(String name){
        return companyRepo.findByName(name);
    }

    public List<Company> getByLocation(String location){
        return companyRepo.findByLocation(location);
    }

}
